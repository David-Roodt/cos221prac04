# cos221prac04
# Set up the databse by logging into mysql via your terminal the running
# SOURCE sakila-schema.sql;
# and
# SOURCE sakila-data.sql;
# then run the jar file located in prac04->target-prac04-1.0.jar using the terminal with
# java -jar prac04-1.0.jar
# or by double clicking run.bat within the same folder
# The appliaction window should pop up and open on the Staff tab